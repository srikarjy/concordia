"""Run: python3 verify.py from the extracted bundle. Uses only the standard library.

Trust this verifier from the original download. Replacing the verifier together
with the files can forge a locally consistent archive; this is not a signature.
"""
import hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parent
def require(condition, message):
    if not condition:
        raise ValueError(message)
snapshots = json.loads((root / "history.json").read_text())
latest = json.loads((root / "review.json").read_text())
previous = None
for item in snapshots:
    payload = dict(item)
    recorded = payload.pop("artifact_digest")
    actual = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    require(actual == recorded, "Snapshot hash mismatch")
    require(payload["previous_digest"] == previous, "Revision chain mismatch")
    previous = recorded
require(snapshots[-1] == latest, "Latest snapshot mismatch")
for index, item in enumerate(latest["inputs"]):
    raw = (root / f"inputs/{index + 1:03d}-{item['kind']}.csv").read_bytes()
    require(hashlib.sha256(raw).hexdigest() == item["sha256"], "Input hash mismatch")
diagnostics_path = root / "diagnostics.json"
if diagnostics_path.exists():
    for name, digest in json.loads(diagnostics_path.read_text()).items():
        raw = (root / "diagnostics" / name).read_bytes()
        require(hashlib.sha256(raw).hexdigest() == digest, "Diagnostic hash mismatch")
expected_files = {'report.html': 'a212d3a34d3f175f6de2bd2450a6c2860b9987a7b39e82bbd28e4326d4c03601', 'selected-candidates.csv': 'd411c3cd198f826f498fb40726c4139f430221ef064ccd6ed82f668295329e5d', 'all-decisions.csv': '06d3899ca0be31ee1b4c2fdb557c1c1a93c4005afaf475639480e40e213fcf01', 'review.json': 'b47fa65bb8cdbcf1cba9835a1c822efb0ae6a78898a7d6a605292f6d05103dbb', 'history.json': 'c20f61302c7979ee5efc6ac84cf60e317948d1e808c0ba6a0dab032e6e3ef32e', 'reference.fasta': '3fef3f3081826e88a498895c26b67075cba64f609d155dd600cb8c01196c5670', 'inputs/001-candidates.csv': '6e41f560c42d80773b36fa7a1f46affc7698dbe7651e8bcb30af488f52514417', 'inputs/002-predictions.csv': '9da652f670ee9b7153b81042574b14751d481c94264adc739761825a390f83f4', 'inputs/003-assay.csv': '9dd3a6dc8209f5b856e8efd8de242ffad3916e6c2f09bf6d7df2de2d265d999d', 'diagnostics.json': '50ab6dc5c264fb0b4337659eeb1e1c7f5f2ab30475ac5c0f5eac0d59f114ea8a', 'diagnostics/execution.json': '935811e94c3f30d4d049e60562943feff98047eb892412a5c24df9555a7c298e', 'diagnostics/measured-dataset.csv': 'b8af3de8d492427941fa237448af88f4a193c0e8b742cdc4d017b0d73da8735f', 'diagnostics/source-reference.fasta': 'a56ce69e9e80a566367b6b4b3a01a263d61e9b5c58dd55e9eb8e49a50bd6b561', 'README.txt': '0e73072ca370700b7701fc68418fa10251444b5d612f3d9ee91c6430cf2ddda2'}
actual_files = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file()}
require(actual_files == set(expected_files) | {"verify.py"}, "Bundle file inventory mismatch")
for name, digest in expected_files.items():
    require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest,
            "Bundle file hash mismatch: " + name)
print("Bundle files, recorded snapshots and input hashes verified. Not biological validation or external attestation.")
