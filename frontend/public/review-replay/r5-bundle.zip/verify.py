"""Run: python3 verify.py from the extracted bundle. Uses only the standard library.

Trust this verifier from the original download. Replacing the verifier together
with the files can forge a locally consistent archive; this is not a signature.
"""
import hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parent
def require(condition, message):
    if not condition:
        raise ValueError(message)
snapshots = json.loads((root / "history.json").read_text())
latest = json.loads((root / "review.json").read_text())
previous = None
for item in snapshots:
    payload = dict(item)
    recorded = payload.pop("artifact_digest")
    actual = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    require(actual == recorded, "Snapshot hash mismatch")
    require(payload["previous_digest"] == previous, "Revision chain mismatch")
    previous = recorded
require(snapshots[-1] == latest, "Latest snapshot mismatch")
for index, item in enumerate(latest["inputs"]):
    raw = (root / f"inputs/{index + 1:03d}-{item['kind']}.csv").read_bytes()
    require(hashlib.sha256(raw).hexdigest() == item["sha256"], "Input hash mismatch")
diagnostics_path = root / "diagnostics.json"
if diagnostics_path.exists():
    for name, digest in json.loads(diagnostics_path.read_text()).items():
        raw = (root / "diagnostics" / name).read_bytes()
        require(hashlib.sha256(raw).hexdigest() == digest, "Diagnostic hash mismatch")
expected_files = {'report.html': '17ad695cf2c1b02dc9d4a39b929f6352b907d6f23733956878cc671c97368a2c', 'selected-candidates.csv': 'fd3ba7de1fc296aa45ef1f899c99d95a42135ec65ccc43dce3abd01e5fc1a4a4', 'all-decisions.csv': 'b658ef85ab97765c928ad664852d3260506c63165fde82b1813d585763d93521', 'review.json': '0fb018534758ffe1aad603a3a0a96d85fa18f5353ac01219f32a9ac25a7a0142', 'history.json': '4909fe5a04342dd0934055dc16a1760fe482c21779fe896639d5977c75a99418', 'reference.fasta': '827eb36b70349af43746ac1296efd4c47ff01b2d0f144d4e295a10b74f45e85e', 'inputs/001-candidates.csv': '041b067d5061f84f5a1c2535eb1d513bc8c9d6a0fdb8c259b642bffd8fe1fcc5', 'inputs/002-predictions.csv': 'c3049aa773fed143c86c63ed0e6c4f124cb62977a071d82b475ef2b2ee10d248', 'diagnostics.json': '6200a2d3cd3ef45aa45c2c5ce6db10532cfd7960e1ca9d01572814f7e263b822', 'diagnostics/thermompnn-feasibility.json': '88906a76e3d9eb498a631443784980bd2ed89cacdde84cd979a27a5c5bf4b2d2', 'README.txt': '0e73072ca370700b7701fc68418fa10251444b5d612f3d9ee91c6430cf2ddda2'}
actual_files = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file()}
require(actual_files == set(expected_files) | {"verify.py"}, "Bundle file inventory mismatch")
for name, digest in expected_files.items():
    require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest,
            "Bundle file hash mismatch: " + name)
print("Bundle files, recorded snapshots and input hashes verified. Not biological validation or external attestation.")
