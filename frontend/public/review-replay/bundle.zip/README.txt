Open report.html to review decisions. selected-candidates.csv is the human shortlist.
review.json and history.json preserve full inputs, evidence and decision revisions.
Run python3 verify.py to verify snapshot hashes, links and raw input files.
No hosted service or model is called. This bundle contains your sequences and evidence; review before sharing.
