"""Run: python3 verify.py from the extracted bundle. Uses only the standard library.

Trust this verifier from the original download. Replacing the verifier together
with the files can forge a locally consistent archive; this is not a signature.
"""
import hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parent
def require(condition, message):
    if not condition:
        raise ValueError(message)
snapshots = json.loads((root / "history.json").read_text())
latest = json.loads((root / "review.json").read_text())
previous = None
for item in snapshots:
    payload = dict(item)
    recorded = payload.pop("artifact_digest")
    actual = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    require(actual == recorded, "Snapshot hash mismatch")
    require(payload["previous_digest"] == previous, "Revision chain mismatch")
    previous = recorded
require(snapshots[-1] == latest, "Latest snapshot mismatch")
for index, item in enumerate(latest["inputs"]):
    raw = (root / f"inputs/{index + 1:03d}-{item['kind']}.csv").read_bytes()
    require(hashlib.sha256(raw).hexdigest() == item["sha256"], "Input hash mismatch")
diagnostics_path = root / "diagnostics.json"
if diagnostics_path.exists():
    for name, digest in json.loads(diagnostics_path.read_text()).items():
        raw = (root / "diagnostics" / name).read_bytes()
        require(hashlib.sha256(raw).hexdigest() == digest, "Diagnostic hash mismatch")
expected_files = {'report.html': '6a3daadae14ae07e62c565f02a1228882fd7182d2df9db4e233ff1725171fae8', 'selected-candidates.csv': '302a118bad0cd62705b498336e77d22a8291381e2e323b6e76a4190f90f747e1', 'all-decisions.csv': 'a6338372216219048c5107a0d8162d98fe0b8dbc9b04e50828e68800a31886fd', 'review.json': 'b4c0c309db1e7901bf4169f480b38f3a2ac563dc164862384e090fe4cc4481d6', 'history.json': 'faa856508457b3c523437ebdf1173fa67a85d88536403eed4ef515f6fdb0a91d', 'reference.fasta': '827eb36b70349af43746ac1296efd4c47ff01b2d0f144d4e295a10b74f45e85e', 'inputs/001-candidates.csv': '041b067d5061f84f5a1c2535eb1d513bc8c9d6a0fdb8c259b642bffd8fe1fcc5', 'inputs/002-predictions.csv': 'c3049aa773fed143c86c63ed0e6c4f124cb62977a071d82b475ef2b2ee10d248', 'diagnostics.json': '6200a2d3cd3ef45aa45c2c5ce6db10532cfd7960e1ca9d01572814f7e263b822', 'diagnostics/thermompnn-feasibility.json': '88906a76e3d9eb498a631443784980bd2ed89cacdde84cd979a27a5c5bf4b2d2', 'README.txt': '0e73072ca370700b7701fc68418fa10251444b5d612f3d9ee91c6430cf2ddda2'}
actual_files = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file()}
require(actual_files == set(expected_files) | {"verify.py"}, "Bundle file inventory mismatch")
for name, digest in expected_files.items():
    require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest,
            "Bundle file hash mismatch: " + name)
print("Bundle files, recorded snapshots and input hashes verified. Not biological validation or external attestation.")
