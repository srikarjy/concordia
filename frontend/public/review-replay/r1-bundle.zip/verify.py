"""Run: python3 verify.py from the extracted bundle. Uses only the standard library."""
import hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parent
snapshots = json.loads((root / "history.json").read_text())
latest = json.loads((root / "review.json").read_text())
previous = None
for item in snapshots:
    payload = dict(item)
    recorded = payload.pop("artifact_digest")
    actual = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    assert actual == recorded, "Snapshot hash mismatch"
    assert payload["previous_digest"] == previous, "Revision chain mismatch"
    previous = recorded
assert snapshots[-1] == latest, "Latest snapshot mismatch"
for index, item in enumerate(latest["inputs"]):
    raw = (root / f"inputs/{index + 1:03d}-{item['kind']}.csv").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == item["sha256"], "Input hash mismatch"
diagnostics_path = root / "diagnostics.json"
if diagnostics_path.exists():
    for name, digest in json.loads(diagnostics_path.read_text()).items():
        raw = (root / "diagnostics" / name).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == digest, "Diagnostic hash mismatch"
print("Recorded snapshots and input hashes verified. Not biological validation or external attestation.")
