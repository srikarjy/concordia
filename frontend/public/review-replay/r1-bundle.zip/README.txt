Open report.html to review decisions. selected-candidates.csv is the human shortlist.
review.json and history.json preserve full inputs, evidence and decision revisions.
When present, diagnostics/ contains exact attached diagnostic records and diagnostics.json records their hashes.
Run python3 verify.py to verify snapshot hashes, links, raw input files, and diagnostics.
No hosted service or model is called. This bundle contains your sequences and evidence; review before sharing.
