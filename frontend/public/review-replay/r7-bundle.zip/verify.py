"""Run: python3 verify.py from the extracted bundle. Uses only the standard library.

Trust this verifier from the original download. Replacing the verifier together
with the files can forge a locally consistent archive; this is not a signature.
"""
import hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parent
def require(condition, message):
    if not condition:
        raise ValueError(message)
snapshots = json.loads((root / "history.json").read_text())
latest = json.loads((root / "review.json").read_text())
previous = None
for item in snapshots:
    payload = dict(item)
    recorded = payload.pop("artifact_digest")
    actual = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    require(actual == recorded, "Snapshot hash mismatch")
    require(payload["previous_digest"] == previous, "Revision chain mismatch")
    previous = recorded
require(snapshots[-1] == latest, "Latest snapshot mismatch")
for index, item in enumerate(latest["inputs"]):
    raw = (root / f"inputs/{index + 1:03d}-{item['kind']}.csv").read_bytes()
    require(hashlib.sha256(raw).hexdigest() == item["sha256"], "Input hash mismatch")
diagnostics_path = root / "diagnostics.json"
if diagnostics_path.exists():
    for name, digest in json.loads(diagnostics_path.read_text()).items():
        raw = (root / "diagnostics" / name).read_bytes()
        require(hashlib.sha256(raw).hexdigest() == digest, "Diagnostic hash mismatch")
expected_files = {'report.html': '7130e388ae3238ec18faafeef546b29c5297470e3f4ecacadc9fd6d40376ee97', 'selected-candidates.csv': 'fe614602709ea2ebd05bf11625658ab6d33e23708bdcc499cbd720a226b23c3f', 'all-decisions.csv': '09b413faa5cf0d72b4e2f3f9665d6320e424c3b05358fff98db8ba79860e783d', 'review.json': '6ea0d0ead6be84b61f154e9da0f6dc55f51115b4bd9b2c0e594f2b2cea9b032b', 'history.json': '811a48cfc75eb558de0493b0ddf5fd877afce40584be807323b074bb1af70ffd', 'reference.fasta': '827eb36b70349af43746ac1296efd4c47ff01b2d0f144d4e295a10b74f45e85e', 'inputs/001-candidates.csv': '041b067d5061f84f5a1c2535eb1d513bc8c9d6a0fdb8c259b642bffd8fe1fcc5', 'inputs/002-predictions.csv': 'c3049aa773fed143c86c63ed0e6c4f124cb62977a071d82b475ef2b2ee10d248', 'inputs/003-assay.csv': 'da8922f10205268e4d37b632d31b06643b65fd26a71f2a89f2d42d120625c2d6', 'diagnostics.json': '6200a2d3cd3ef45aa45c2c5ce6db10532cfd7960e1ca9d01572814f7e263b822', 'diagnostics/thermompnn-feasibility.json': '88906a76e3d9eb498a631443784980bd2ed89cacdde84cd979a27a5c5bf4b2d2', 'README.txt': '0e73072ca370700b7701fc68418fa10251444b5d612f3d9ee91c6430cf2ddda2'}
actual_files = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file()}
require(actual_files == set(expected_files) | {"verify.py"}, "Bundle file inventory mismatch")
for name, digest in expected_files.items():
    require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest,
            "Bundle file hash mismatch: " + name)
print("Bundle files, recorded snapshots and input hashes verified. Not biological validation or external attestation.")
