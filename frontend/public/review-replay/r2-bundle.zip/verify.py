"""Run: python3 verify.py from the extracted bundle. Uses only the standard library.

Trust this verifier from the original download. Replacing the verifier together
with the files can forge a locally consistent archive; this is not a signature.
"""
import hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parent
def require(condition, message):
    if not condition:
        raise ValueError(message)
snapshots = json.loads((root / "history.json").read_text())
latest = json.loads((root / "review.json").read_text())
previous = None
for item in snapshots:
    payload = dict(item)
    recorded = payload.pop("artifact_digest")
    actual = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    require(actual == recorded, "Snapshot hash mismatch")
    require(payload["previous_digest"] == previous, "Revision chain mismatch")
    previous = recorded
require(snapshots[-1] == latest, "Latest snapshot mismatch")
for index, item in enumerate(latest["inputs"]):
    raw = (root / f"inputs/{index + 1:03d}-{item['kind']}.csv").read_bytes()
    require(hashlib.sha256(raw).hexdigest() == item["sha256"], "Input hash mismatch")
diagnostics_path = root / "diagnostics.json"
if diagnostics_path.exists():
    for name, digest in json.loads(diagnostics_path.read_text()).items():
        raw = (root / "diagnostics" / name).read_bytes()
        require(hashlib.sha256(raw).hexdigest() == digest, "Diagnostic hash mismatch")
expected_files = {'report.html': 'e9dda1a17372f63e4d076cb52a923f5a71cf6e011a44e25f85ffea671b90f4a1', 'selected-candidates.csv': '2f8b6f2dfd27eee440fc9f1d7b5b01de175e8bddcf070b91e2e30668f77dae2e', 'all-decisions.csv': 'd487dd18481dcbd513210f18eff420cef514cf65d60f2dff789fe2d43e62a0f1', 'review.json': 'ef19ed66daef21ec48022c749c8a171160a712145ee061a3e42facf1d0f4626d', 'history.json': 'a7a7df323596dc31f723a747f62c3685b66d17e6d72f6905299f239d6b16b1ab', 'reference.fasta': '827eb36b70349af43746ac1296efd4c47ff01b2d0f144d4e295a10b74f45e85e', 'inputs/001-candidates.csv': '041b067d5061f84f5a1c2535eb1d513bc8c9d6a0fdb8c259b642bffd8fe1fcc5', 'inputs/002-predictions.csv': 'c3049aa773fed143c86c63ed0e6c4f124cb62977a071d82b475ef2b2ee10d248', 'diagnostics.json': '6200a2d3cd3ef45aa45c2c5ce6db10532cfd7960e1ca9d01572814f7e263b822', 'diagnostics/thermompnn-feasibility.json': '88906a76e3d9eb498a631443784980bd2ed89cacdde84cd979a27a5c5bf4b2d2', 'README.txt': '0e73072ca370700b7701fc68418fa10251444b5d612f3d9ee91c6430cf2ddda2'}
actual_files = {str(path.relative_to(root)) for path in root.rglob("*") if path.is_file()}
require(actual_files == set(expected_files) | {"verify.py"}, "Bundle file inventory mismatch")
for name, digest in expected_files.items():
    require(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest,
            "Bundle file hash mismatch: " + name)
print("Bundle files, recorded snapshots and input hashes verified. Not biological validation or external attestation.")
